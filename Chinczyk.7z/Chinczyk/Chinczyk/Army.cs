﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace Chinczyk
{
    public class Army
    {
        public Pawn[] Pawns { get; private set; }

        public string LocalName { get; private set; }

        public int PawnsOnBoard;
        public int PawnsOnEnd;

        public int TurnCounter = 1;

        public int Beginning { get; private set; }
        public int End { get; private set; }

        private System.Windows.Thickness[] EndingPositions;
        private System.Windows.Thickness[] StartingPositions;

        private MainWindow LocalMainWindow;

        public Army(MainWindow MainWindow, string Name, int BeginningField, Pawn[] PawnsTable, System.Windows.Controls.Image[] PawnsEndingPositions)
        {
            LocalMainWindow = MainWindow;

            LocalName = Name;

            EndingPositions = new System.Windows.Thickness[4];
            StartingPositions = new System.Windows.Thickness[4];

            Pawns = new Pawn[4];

            Pawns = PawnsTable;

            StartingPositions[0] = Pawns[0].Position;
            StartingPositions[1] = Pawns[1].Position;
            StartingPositions[2] = Pawns[2].Position;
            StartingPositions[3] = Pawns[3].Position;

            EndingPositions[0] = PawnsEndingPositions[0].Margin;
            EndingPositions[1] = PawnsEndingPositions[1].Margin;
            EndingPositions[2] = PawnsEndingPositions[2].Margin;
            EndingPositions[3] = PawnsEndingPositions[3].Margin;

            Beginning = BeginningField;
            End = (BeginningField - 1 >= 0) ? BeginningField - 1 : 39;
        }

        public bool ClearField(int Field)
        {
            foreach (Pawn P in Pawns)
                if (P.Field == Field) { MoveToStart(P);  return true; }

            return false;
        }

        public bool MoveToStart(Pawn Pawn)
        {
            foreach (System.Windows.Thickness Field in StartingPositions)
            {
                if (Pawns[0].Position != Field && Pawns[1].Position != Field && Pawns[2].Position != Field && Pawns[3].Position != Field)
                {
                    BasicPawnMovement(Pawn, Field, 700);
                    Pawn.Field = null;
                    Pawn.IsOnStart = true;
                    PawnsOnBoard--;
                    return true;
                }
            }

            return false;
        }

        public bool MoveToBeginning(Pawn Pawn)
        {
            if (Pawn.IsOnEnd) return false;

            foreach (Pawn P in Pawns)
                if (P.Position == LocalMainWindow.Fields[Beginning]) return false;

            BasicPawnMovement(Pawn, LocalMainWindow.Fields[Beginning], 500);
            PawnsOnBoard++;

            Pawn.Field = Beginning;
            Pawn.IsOnStart = false;

            return true;
        }

        public bool MoveToBeginning(int PawnIndex)
        {
            return MoveToBeginning(Pawns[PawnIndex]);
        }

        public bool IsFieldFree(int Field)
        {
            foreach (Pawn P in Pawns)
                if (P.Field == Field) return false;

            return true;
        }

        public bool MoveToEnd(Pawn Pawn)
        {
            BasicPawnMovement(Pawn, EndingPositions[PawnsOnEnd], 700);
            PawnsOnBoard--;
            PawnsOnEnd++;

            Pawn.IsOnEnd = true;

            return true;
        }

        public void UnlockAllPawns()
        {
            foreach (Pawn P in Pawns)
                P.UnlockPawn();
        }

        public void LockAllPawns()
        {
            foreach (Pawn P in Pawns)
                P.LockPawn();
        }

        public bool BasicPawnMovement(Pawn Pawn, System.Windows.Thickness EndingPosition, int Duration)
        {
            Pawn.Animations.Enqueue(PrepereAnimation(Pawn, EndingPosition, Duration));

            return true;
        }

        public ThicknessAnimation PrepereAnimation(Pawn Pawn, System.Windows.Thickness EndingPosition, int Duration)
        {
            ThicknessAnimation Animation = new ThicknessAnimation(Pawn.Position, EndingPosition, TimeSpan.FromMilliseconds(Duration));

            CubicEase TmpEasingFunction = new CubicEase();
            TmpEasingFunction.EasingMode = EasingMode.EaseInOut;

            Animation.EasingFunction = TmpEasingFunction;

            return Animation;
        }

    }

}
