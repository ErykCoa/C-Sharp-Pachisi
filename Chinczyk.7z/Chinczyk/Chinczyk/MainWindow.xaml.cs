﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Animation;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;


namespace Chinczyk
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public Thickness[] Fields;

        public Army[] ArmyTable;

        private Game LocalGame;

        public MainWindow()
        {
            InitializeComponent();

            Fields = new Thickness[] { Field1.Margin, Field2.Margin, Field3.Margin, Field4.Margin, Field5.Margin, Field6.Margin, Field7.Margin, Field8.Margin, Field9.Margin, Field10.Margin, Field11.Margin, Field12.Margin, Field13.Margin, Field14.Margin, Field15.Margin, Field16.Margin, Field17.Margin, Field18.Margin, Field19.Margin, Field20.Margin, Field21.Margin, Field22.Margin, Field23.Margin, Field24.Margin, Field25.Margin, Field26.Margin, Field27.Margin, Field28.Margin, Field29.Margin, Field30.Margin, Field31.Margin, Field32.Margin, Field33.Margin, Field34.Margin, Field35.Margin, Field36.Margin, Field37.Margin, Field38.Margin, Field39.Margin, Field40.Margin };

            ArmyTable = new Army[4];

            ArmyTable[0] = new Army(this, "Red", 0, new Pawn[4] { RedPawn1, RedPawn2, RedPawn3, RedPawn4 }, new Image[4] { RedEnd1, RedEnd2, RedEnd3, RedEnd4 });

            ArmyTable[1] = new Army(this, "Blue", 10, new Pawn[4] { BluePawn1, BluePawn2, BluePawn3, BluePawn4 }, new Image[4] { BlueEnd1, BlueEnd2, BlueEnd3, BlueEnd4 });

            ArmyTable[2] = new Army(this, "Green", 20, new Pawn[4] { GreenPawn1, GreenPawn2, GreenPawn3, GreenPawn4 }, new Image[4] { GreenEnd1, GreenEnd2, GreenEnd3, GreenEnd4 });

            ArmyTable[3] = new Army(this, "Yellow", 30, new Pawn[4] { YellowPawn1, YellowPawn2, YellowPawn3, YellowPawn4 }, new Image[4] { YellowEnd1, YellowEnd2, YellowEnd3, YellowEnd4 });           

            Dice.IsEnabled = true;
        }

        private void Pawn_Click(object sender, RoutedEventArgs e)
        {
            Pawn Pawn = LocalGame.FindPawn(((Button)sender).Margin);

            if (!LocalGame.PawnMovement(Pawn)) return;
            Dice.IsEnabled = true;
            LocalGame.LockPawns();

            LocalGame.StartAllAnimations();

            if (LocalGame.TurnShouldEnd()) LocalGame.NextTurn();

        }

        private void Dice_Click(object sender, RoutedEventArgs e)
        {
            if (LocalGame.TurnShouldEnd()) { LocalGame.NextTurn(); return; }

            LocalGame.RollTheDice();

            Dice.Content = LocalGame.LastDiceRoll.ToString();

            if (LocalGame.DiceShouldBeLocked()) Dice.IsEnabled = false;

            LocalGame.UnlockPawns();
            LocalGame.IncrementTurnCounter();

            LocalGame.StartAllAnimations();
        }

        private void SinglePlayer_Click(object sender, RoutedEventArgs e)
        {
            LocalGame = new Game(this, 1);
            TitleScreen.Visibility = Visibility.Hidden;
        }

        private void TwoPlayers_Click(object sender, RoutedEventArgs e)
        {
            LocalGame = new Game(this, 2);
            TitleScreen.Visibility = Visibility.Hidden;
        }

        private void ThreePlayers_Click(object sender, RoutedEventArgs e)
        {
            LocalGame = new Game(this, 3);
            TitleScreen.Visibility = Visibility.Hidden;
        }

        private void FourPlayers_Click(object sender, RoutedEventArgs e)
        {
            LocalGame = new Game(this, 4);
            TitleScreen.Visibility = Visibility.Hidden;
        }
    }
}
