﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chinczyk
{
    class Player
    {

        public Army LocalArmy;

        public Player NextPlayer;

        protected MainWindow LocalMainWindow;

        public Player(MainWindow MainWindow, Army Info)
        {
            LocalMainWindow = MainWindow;

            LocalArmy = Info;
        }

        public Player() { }

        virtual public void StartTurn()
        {
            LocalMainWindow.Dice.IsEnabled = true;
            LocalMainWindow.Dice.Content = LocalArmy.LocalName[0];
            LocalArmy.TurnCounter = 1;
        }
        virtual public void EndTurn()
        {
            LocalArmy.LockAllPawns();

            if(LocalArmy.PawnsOnEnd == 4)
            {
                LocalMainWindow.VictoryMsg.Text = $"Player {LocalArmy.LocalName} is victorious!";
                LocalMainWindow.VictoryGrid.Visibility = System.Windows.Visibility.Visible;
            }
        }

        virtual public bool IsAI() => false;

        public bool PawnMovement(Pawn SelectedPawn, int LastDiceRoll)
        {
            if (SelectedPawn.IsOnEnd) return false;

            if (SelectedPawn.IsOnStart)
            {
                if (LastDiceRoll == 6)
                {
                    ClearField(LocalArmy.Beginning);

                    return LocalArmy.MoveToBeginning(SelectedPawn);
                }
                return false;
            }

            int Field = (int) SelectedPawn.Field;

            if (Field <= LocalArmy.End && LocalArmy.End < Field + LastDiceRoll) { LocalArmy.MoveToEnd(SelectedPawn); PlayerHasMovedPawn(); return true; }

            if (PawnCollision(SelectedPawn, LastDiceRoll)) return false;

            Field = (Field + LastDiceRoll < 40) ? Field + LastDiceRoll : Field + LastDiceRoll - 40;

            MovePawnToField(SelectedPawn, Field);

            PlayerHasMovedPawn();

            return true;
        }

        private bool PawnCollision(Pawn SelectedPawn, int LastDiceRoll)
        {
            int Field = (int) SelectedPawn.Field;

            Field = (Field + LastDiceRoll < 40) ? Field + LastDiceRoll : Field + LastDiceRoll - 40;

            if (!LocalArmy.IsFieldFree(Field)) return true;

            ClearField(Field);

            return false;
        }

        private void ClearField(int Field)
        {
            NextPlayer.LocalArmy.ClearField(Field);
            NextPlayer.NextPlayer.LocalArmy.ClearField(Field);
            NextPlayer.NextPlayer.NextPlayer.LocalArmy.ClearField(Field);
        }

        private void PlayerHasMovedPawn()
        {
            LocalArmy.TurnCounter = 4;
        }

        private int MovePawnToField(Pawn Pawn, int EndingField)
        {
            if (Pawn.Field == EndingField) return 0;

            RecursiveMovement(Pawn, (int)Pawn.Field, EndingField);

            Pawn.Field = EndingField;

            return 1;
        }

        private void RecursiveMovement(Pawn Pawn, int StartingField, int EndingField)
        {
            if (StartingField == EndingField)
            {
                return;
            }

            Pawn.Animations.Enqueue(LocalArmy.PrepereAnimation(Pawn, LocalMainWindow.Fields[(StartingField < 39) ? StartingField + 1 : 0], 130));

            RecursiveMovement(Pawn, (StartingField < 39) ? StartingField + 1 : 0, EndingField);
        }
    }
}

