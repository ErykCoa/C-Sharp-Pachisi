﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;

namespace Chinczyk
{
    public class Pawn
    {
        public Button LocalPawn;
        public Thickness Position { get { return LocalPawn.Margin; } set { LocalPawn.Margin = value; } }

        public int? Field;

        public bool IsOnStart;
        public bool IsOnEnd { get { return Field == null && IsOnStart == false; } set { if (value) { IsOnStart = false; Field = null; } } }

        public Queue<ThicknessAnimation> Animations;
        public bool AnimationsBusyFlag;

        public Pawn(Button SelectedPawn)
        {
            LocalPawn = SelectedPawn;
            Animations = new Queue<ThicknessAnimation>();
            Field = null;
            IsOnStart = true;
            AnimationsBusyFlag = false;
        }

        public void UnlockPawn() => LocalPawn.IsEnabled = true;

        public void LockPawn() => LocalPawn.IsEnabled = false;

        public static implicit operator Pawn(Button B) =>  new Pawn(B);
    }
}
