﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows.Media.Animation;

namespace Chinczyk
{
    class AI : Player
    {
        Dice LocalDice;

        public AI(MainWindow MainWindow, Army Info)
        {
            LocalMainWindow = MainWindow;

            LocalArmy = Info;

            LocalDice = new Dice();

        }

        override public bool IsAI() => true;

        override public void StartTurn()
        {
            LocalMainWindow.Dice.IsEnabled = false;
            LocalMainWindow.Dice.Content = "";
            LocalArmy.TurnCounter = 1;

            while (3 >= LocalArmy.TurnCounter++ && LocalArmy.PawnsOnBoard == 0)
                if (LocalDice.Roll() == 6) for (int index = 0; index < 4 && !PawnMovement(LocalArmy.Pawns[index], 6); index++) ;     

            if (LocalArmy.PawnsOnBoard != 0)
            {
                int Movement = 0;

                do
                {
                    Movement = LocalDice.Roll();
                    for (int index = 0; index < 4 && !PawnMovement(LocalArmy.Pawns[index], Movement); index++) ;
                } while (Movement == 6);
            }
        }

        override public void EndTurn()
        {
            if (LocalArmy.PawnsOnEnd == 4)
            {
                LocalMainWindow.VictoryMsg.Text = $"Player {LocalArmy.LocalName} is victorious!";
                LocalMainWindow.VictoryGrid.Visibility = System.Windows.Visibility.Visible;
            }
        }
    }
}
