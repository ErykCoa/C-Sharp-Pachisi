﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Chinczyk
{
    class Dice
    {
        private static Random x = new Random();
        public int Roll()
        {
            return (x.Next(6) + 1);
        }
    }
}
