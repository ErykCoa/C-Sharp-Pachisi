﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chinczyk
{
    class Game
    {
        public int LastDiceRoll { get; private set; }

        private Players LocalPlayers;

        private Dice LocalDice;

        public Game(MainWindow Window, int NumberOfHumanPlayers)
        {
            MainWindow LocalMainWindow = Window;

            LocalDice = new Dice();

            Player[] PlayersTable = new Player[4];

            for(int index = 0; index < 4; index++)
            {
                if (index < NumberOfHumanPlayers) PlayersTable[index] = new Player(Window, Window.ArmyTable[index]);
                else PlayersTable[index] = new AI(Window, Window.ArmyTable[index]);
            }
   
            LocalPlayers = new Players(Window, PlayersTable);

            UnlockPawns();

            LastDiceRoll = 0;
        }

        public void IncrementTurnCounter() => LocalPlayers.CurrentPlayer.LocalArmy.TurnCounter++;

        public bool PawnMovement(Pawn SelectedPawn) => LocalPlayers.PawnMovement(SelectedPawn, LastDiceRoll);

        public Pawn FindPawn(Thickness Position) => LocalPlayers.FindPawn(Position);

        public void RollTheDice() => LastDiceRoll = LocalDice.Roll();

        public void StartAllAnimations() => LocalPlayers.StartAllAnimations();

        public bool TurnShouldEnd()
        {
            if (LocalPlayers.CurrentPlayer.LocalArmy.PawnsOnEnd == 4) return true;

            if (LocalPlayers.CurrentPlayer.LocalArmy.TurnCounter == 1 ||
                LastDiceRoll == 6 ||
                (LocalPlayers.CurrentPlayer.LocalArmy.TurnCounter <= 3 && LocalPlayers.CurrentPlayer.LocalArmy.PawnsOnBoard == 0))
                return false;

            return true;
        }


        public bool DiceShouldBeLocked()
        {
            if (LastDiceRoll != 6 && LocalPlayers.CurrentPlayer.LocalArmy.PawnsOnBoard == 0) return false;

            return true;
        }

        public void NextTurn()
        {
            LocalPlayers.EndTurn();

            LocalPlayers.ChangePlayer();

            LocalPlayers.StartTurn();
        }

        public void UnlockPawns()
        {
            Pawn Pawn;
            for (int index = 4; index-- != 0;)
            {
                Pawn = LocalPlayers.CurrentPlayer.LocalArmy.Pawns[index];
                if (!Pawn.IsOnEnd && (!Pawn.IsOnStart || (LastDiceRoll == 6 && LocalPlayers.CurrentPlayer.LocalArmy.IsFieldFree(LocalPlayers.CurrentPlayer.LocalArmy.Beginning))))
                {
                    Pawn.UnlockPawn();
                }
            }
        }

        public void LockPawns()
        {
            Pawn Pawn;
            for (int index = 4; index-- != 0;)
            {
                Pawn = LocalPlayers.CurrentPlayer.LocalArmy.Pawns[index];
                Pawn.LockPawn();
            }
        }
    }
}