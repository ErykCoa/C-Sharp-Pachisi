﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media.Animation;
using System.Windows.Shapes;

namespace Chinczyk
{
    class Players
    {
        public Player CurrentPlayer { get; private set; }

        private Player[] LocalPlayersTable;

        private MainWindow LocalMainWindow;

        public Players(MainWindow Window, Player[] PlayersTable)
        {
            LocalMainWindow = Window;

            LocalPlayersTable = PlayersTable;

            LocalPlayersTable[0].NextPlayer = LocalPlayersTable[1];
            LocalPlayersTable[1].NextPlayer = LocalPlayersTable[2];
            LocalPlayersTable[2].NextPlayer = LocalPlayersTable[3];
            LocalPlayersTable[3].NextPlayer = LocalPlayersTable[0];

            CurrentPlayer = LocalPlayersTable[0];
        }

        public void ChangePlayer()
        {
            CurrentPlayer = CurrentPlayer.NextPlayer;
        }

        public void EndTurn()
        {
            StartAllAnimations();
            CurrentPlayer.EndTurn();
        }

        public void StartTurn()
        {
            StartAllAnimations();
            CurrentPlayer.StartTurn();
            while (CurrentPlayer.IsAI())
            {
                StartAllAnimations();
                CurrentPlayer.EndTurn();
                ChangePlayer();
                CurrentPlayer.StartTurn();
            }
        }

        public bool PawnMovement(Pawn SelectedPawn, int LastDiceRoll) => CurrentPlayer.PawnMovement(SelectedPawn, LastDiceRoll);

        public Pawn FindPawn(Thickness Position)
        {
            foreach(Pawn P in CurrentPlayer.LocalArmy.Pawns)
            {
                if (P.Position == Position) return P;
            }

            return null;
        }

        public void StartAllAnimations()
        {
            foreach(Army A in LocalMainWindow.ArmyTable)
                foreach(Pawn P in A.Pawns)
                {
                    if (!P.AnimationsBusyFlag) StartAnimation(P, P.LocalPawn.Margin);
                }
        }

        private void StartAnimation(Pawn Pawn, Thickness From)
        {
           if (!Pawn.Animations.Any()) { Pawn.AnimationsBusyFlag = false; return; }

            Pawn.AnimationsBusyFlag = true;

            ThicknessAnimation Animation = Pawn.Animations.Dequeue();

            Animation.From = From;

            Animation.Completed += new EventHandler((s, e) => StartAnimation(Pawn, (Thickness) Animation.To) );

            Pawn.LocalPawn.BeginAnimation(Rectangle.MarginProperty, Animation);
        }
    }
}
